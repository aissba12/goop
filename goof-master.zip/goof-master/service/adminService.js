// @TODO use this adminService file once Snyk Code for VSCode
// is able to navigate to cross-file paths in the vuln description 
/** 
module.exports.adminLoginSuccess = function(redirectPage, res) {
    console.log({redirectPage})
    if (redirectPage) {
        return res.redirect(redirectPage)
    } else {
        return res.redirect('/admin')
    }
}
*/